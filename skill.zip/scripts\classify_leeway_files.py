#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


RULES = [
    ("old proof artifact", [".png", ".jpg", ".jpeg"], ["button", "proof", "screenshot"]),
    ("generated debug artifact", [".html", ".js", ".json", ".png"], ["debug", "extract_html", "run_get_html", "_vsix_inspect", "vsix-smoke"]),
    ("generated", [".json", ".log", ".md"], ["test-evidence", "reports", "receipts"]),
    ("quarantine", [".js", ".ts"], ["backup", "broken", "deprecated", "dist/extension.js"]),
    ("active UI asset", [".png", ".svg", ".tsx", ".ts", ".css", ".html"], ["media", "visual", "ui", "panel"]),
]


def read_text_auto(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig")
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")

    for encoding in ("utf-8", "utf-16-le", "utf-16-be"):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def classify(path_text: str) -> str:
    lowered = path_text.replace("\\", "/").lower()
    for label, extensions, hints in RULES:
        if any(lowered.endswith(ext) for ext in extensions) and any(hint in lowered for hint in hints):
            return label
    return "unknown / do not delete"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to newline-delimited file inventory")
    args = parser.parse_args()

    lines = [line.strip() for line in read_text_auto(Path(args.input)).splitlines() if line.strip()]
    results = [{"path": line, "classification": classify(line)} for line in lines]
    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
