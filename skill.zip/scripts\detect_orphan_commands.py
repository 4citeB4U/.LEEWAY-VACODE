#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


REGISTER_RE = re.compile(r'registerCommand\(\s*"([^"]+)"')
WEBVIEW_EMIT_RE = re.compile(r'vscode\.postMessage\(\s*\{[^{}]*command\s*:\s*"([^"]+)"', re.S)
HOST_EMIT_RE = re.compile(r'webview\.postMessage\(\s*\{[^{}]*command\s*:\s*"([^"]+)"', re.S)
HANDLED_RE = re.compile(r'msg\.command\s*===\s*"([^"]+)"')


def read_text_auto(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig")
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")

    for encoding in ("utf-8", "utf-16-le", "utf-16-be"):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def load_graph_commands(graph_path: Path) -> set[str]:
    data = json.loads(read_text_auto(graph_path))
    commands = set()
    for node in data.get("graph", {}).get("nodes", []):
        for key in ("registeredCommands", "commandsEmitted", "commandsHandled"):
            for value in node.get(key, []) or []:
                commands.add(str(value))
    return commands


def source_files(src_root: Path) -> list[Path]:
    return [path for path in src_root.rglob("*") if path.is_file() and path.suffix in {".ts", ".tsx", ".js", ".jsx"}]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", required=True)
    parser.add_argument("--src", required=True)
    parser.add_argument("--graph", required=True)
    args = parser.parse_args()

    package_json = json.loads(read_text_auto(Path(args.package)))
    manifest_commands = {
        item["command"]
        for item in package_json.get("contributes", {}).get("commands", [])
        if isinstance(item, dict) and item.get("command")
    }

    registered = set()
    emitted = set()
    handled = set()
    for file_path in source_files(Path(args.src)):
        text = read_text_auto(file_path)
        registered.update(REGISTER_RE.findall(text))
        emitted.update(WEBVIEW_EMIT_RE.findall(text))
        emitted.update(HOST_EMIT_RE.findall(text))
        handled.update(HANDLED_RE.findall(text))

    graph_commands = load_graph_commands(Path(args.graph))
    report = {
        "manifest_without_graph_owner": sorted(manifest_commands - graph_commands),
        "registered_without_graph_owner": sorted(registered - graph_commands),
        "emitted_without_graph_owner": sorted(emitted - graph_commands),
        "handled_without_graph_owner": sorted(handled - graph_commands),
    }
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
