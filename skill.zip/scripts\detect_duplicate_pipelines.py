#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


DUPLICATE_HINTS = [
    "backup",
    "broken",
    "deprecated",
    "_archive",
    "/dist/",
    "/out/",
]


def read_text_auto(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig")
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")

    for encoding in ("utf-8", "utf-16-le", "utf-16-be"):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to newline-delimited file inventory")
    args = parser.parse_args()

    paths = [line.strip().replace("\\", "/") for line in read_text_auto(Path(args.input)).splitlines() if line.strip()]
    flagged = [path for path in paths if any(hint in path.lower() for hint in DUPLICATE_HINTS)]

    grouped = {}
    for path in flagged:
        base = path.split("/")[-1]
        grouped.setdefault(base, []).append(path)

    duplicates = {base: items for base, items in grouped.items() if len(items) > 1 or any(token in base.lower() for token in ["backup", "broken", "deprecated"])}
    print(json.dumps({"duplicates": duplicates, "count": len(duplicates)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
