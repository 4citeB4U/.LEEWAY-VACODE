#!/usr/bin/env python3
import argparse
import json
import sys
from pathlib import Path


REQUIRED_NODE_KEYS = {
    "id",
    "name",
    "classification",
    "owner",
    "domain",
    "pipeline",
    "file",
    "runtimeRole",
    "verification",
    "status",
}


def read_text_auto(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig")
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")

    for encoding in ("utf-8", "utf-16-le", "utf-16-be"):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", required=True, help="Path to leeway-application-identity-graph-result.json")
    parser.add_argument("--min-nodes", type=int, default=1)
    parser.add_argument("--min-files", type=int, default=1)
    args = parser.parse_args()

    graph_path = Path(args.graph)
    data = json.loads(read_text_auto(graph_path))
    summary = data.get("summary", {})
    nodes = data.get("graph", {}).get("nodes", [])
    required_files = data.get("graph", {}).get("requiredFiles", [])

    failures = []

    if not data.get("passed", False):
      failures.append("identity graph gate result is not passing")
    if summary.get("registeredNodes", 0) < args.min_nodes:
      failures.append(f"registeredNodes below minimum: {summary.get('registeredNodes', 0)} < {args.min_nodes}")
    if summary.get("registeredFiles", 0) < args.min_files:
      failures.append(f"registeredFiles below minimum: {summary.get('registeredFiles', 0)} < {args.min_files}")

    seen_ids = set()
    for index, node in enumerate(nodes):
        missing = sorted(REQUIRED_NODE_KEYS - set(node.keys()))
        if missing:
            failures.append(f"node[{index}] missing keys: {', '.join(missing)}")
        node_id = node.get("id", "")
        if node_id in seen_ids:
            failures.append(f"duplicate node id: {node_id}")
        seen_ids.add(node_id)

    if len(required_files) != len(set(required_files)):
        failures.append("duplicate required files detected")

    if failures:
        print(json.dumps({"ok": False, "failures": failures}, indent=2))
        return 1

    print(json.dumps({
        "ok": True,
        "registeredNodes": summary.get("registeredNodes", 0),
        "registeredFiles": summary.get("registeredFiles", 0),
        "graph": str(graph_path),
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
