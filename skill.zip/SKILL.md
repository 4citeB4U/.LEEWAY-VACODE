---
name: leeway-application-standards
description: Build, refactor, cleanse, repair, classify, package, and verify LeeWay-governed application code with identity-first rules. Use when Codex must create or change runtime files, commands, events, pipelines, gates, evidence, receipts, or cleanup plans and the work must start in LeeWay form instead of being normalized later.
---

# LeeWay Application Standards

Apply LeeWay construction law from the first draft. Do not treat LeeWay as a post-build checklist.

## Core Workflow

1. Identify the affected LeeWay nodes before editing code.
2. Read `references/leeway-creation-law.md` and `references/leeway-identity-graph-standard.md` if the change adds, removes, or reroutes runtime behavior.
3. Classify every touched file as `ACTIVE`, `FALLBACK`, `EVIDENCE`, `GENERATED`, `QUARANTINE`, or `DELETE_PENDING`.
4. Update the identity graph before calling the work complete.
5. Prefer removal or quarantine over patching around duplicate paths.
6. Run the relevant LeeWay verification surfaces.
7. Write or preserve evidence and receipts.

## Non-Negotiable Laws

- Do not leave active code without a LeeWay ID.
- Do not add a command without registering its owner and route.
- Do not add an event without a source, consumer, and verification path.
- Do not create a second runtime source of truth.
- Do not hide stale production drift with packaging ignores alone when deletion or quarantine is required.
- Do not declare feature completion until the LeeWay gate passes.

## Identity Graph Standard

- Use the ID pattern `LEEWAY_APP::<DOMAIN>::<PIPELINE>::<NODE>`.
- For every new active node, record:
  `id`, `name`, `classification`, `owner`, `domain`, `pipeline`, `file`, `inputs`, `outputs`, `commandsEmitted`, `commandsHandled`, `eventsEmitted`, `eventsHandled`, `verification`, `evidence`, `status`
- If a node is not production-active, mark it explicitly as fallback, evidence, generated, quarantine, or delete-pending.
- If a file participates in runtime, build, governance, packaging, evidence, or receipts, give it an owner path in the graph.

Read `references/leeway-identity-graph-standard.md` for the field contract and taxonomy.

## Production Cleanse Rules

- Classify suspicious files before deleting them.
- Delete one category at a time.
- Run the identity graph gate and the application integrity gate after each deletion group.
- Commit each safe deletion group separately.

Read `references/leeway-production-cleanse-standard.md` before cleanup work.

## Integrity and Repair Rules

- Treat anonymous files, orphan commands, duplicate pipelines, stale package paths, and context contamination as repair targets.
- Use the helper scripts for deterministic checks:
  - `scripts/validate_leeway_identity_graph.py`
  - `scripts/classify_leeway_files.py`
  - `scripts/detect_duplicate_pipelines.py`
  - `scripts/detect_orphan_commands.py`
- Mirror findings back into the repo’s authoritative gates rather than leaving them as ad hoc script output.

Read `references/leeway-self-healing-repair-flow.md` for the repair loop and `references/leeway-application-integrity-gate-standard.md` for gate expectations.

## References

- Read `references/leeway-creation-law.md` for the creation law.
- Read `references/leeway-identity-graph-standard.md` for node and taxonomy requirements.
- Read `references/leeway-production-cleanse-standard.md` for cleanup sequencing.
- Read `references/leeway-application-integrity-gate-standard.md` for gate closure conditions.
- Read `references/leeway-self-healing-repair-flow.md` for drift-repair flow.
- Read `references/leeway-naming-taxonomy.md` when choosing IDs, classifications, and owner names.

## Script Usage

Use these scripts when deterministic checks are faster or less error-prone than ad hoc reasoning:

```bash
python scripts/validate_leeway_identity_graph.py --graph path/to/leeway-application-identity-graph-result.json
python scripts/classify_leeway_files.py --input path/to/file-inventory.txt
python scripts/detect_duplicate_pipelines.py --input path/to/file-inventory.txt
python scripts/detect_orphan_commands.py --package path/to/package.json --src path/to/src --graph path/to/leeway-application-identity-graph-result.json
```

Treat script output as support for LeeWay law, not as a substitute for engineering judgment.
