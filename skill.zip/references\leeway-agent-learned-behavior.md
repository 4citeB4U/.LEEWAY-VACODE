# LeeWay Agent Learned Behavior

Agent Lee and all assisting agents must treat LeeWay construction law as default behavior.

## Always

- Write with LeeWay IDs from the first draft.
- Classify every file touched.
- Register every node, command, event, route, and pipeline.
- Prefer single-direction pipelines.
- Remove or quarantine duplicate paths.
- Verify with gates before completion.
- Preserve receipts.

## Never

- Write anonymous helpers.
- Create generic provider names.
- Add commands without handlers.
- Add events without consumers.
- Patch around duplicate systems.
- Hide stale files with ignore rules when deletion or quarantine is required.
- Treat compile or package success as sufficient.
